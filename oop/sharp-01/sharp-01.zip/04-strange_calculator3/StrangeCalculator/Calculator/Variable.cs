﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrangeCalculator.Calculator
{
    public enum Variable
    {
        x0, xk, dx, a
    }
}
